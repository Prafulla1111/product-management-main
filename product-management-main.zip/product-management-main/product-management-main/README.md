# product-management
for task purpose
Product Management Page
This is a simple web application for managing products. It allows users to add, edit, and delete products. The application is built using ASP.NET Core.
Features
•	Add Product: Users can add new products by providing a name and price.
•	Edit Product: Existing products can be edited, including their name and price.
•	Delete Product: Products can be removed from the system.
•	Display All Products: Users can view a list of all products currently in the system.
Technologies Used
•	ASP.NET Core
•	HTML/CSS
•	C#
How to Use
1.	Clone the repository to your local machine.
2.	Open the solution in Visual Studio (or any other compatible IDE).
3.	Build and run the application.
4.	Access the product management page via the provided URL.
5.	Use the provided functionality to manage products.
Screenshots
Include some screenshots here to showcase the user interface and the functionality of your product management page.
Product Management Page
This is a simple web application for managing products. It allows users to add, edit, and delete products. The application is built using ASP.NET Core.
Features
•	Add Product: Users can add new products by providing a name and price.
•	Edit Product: Existing products can be edited, including their name and price.
•	Delete Product: Products can be removed from the system.
•	Display All Products: Users can view a list of all products currently in the system.
Technologies Used
•	ASP.NET Core
•	HTML/CSS
•	C#
How to Use
1.	Clone the repository to your local machine.
2.	Open the solution in Visual Studio (or any other compatible IDE).
3.	Build and run the application.
4.	Access the product management page via the provided URL.
5.	Use the provided functionality to manage products.
Screenshots
Include some screenshots here to showcase the user interface and the functionality of  product management page.
1.	Main Page 
 2. Product tab view 
3. Click on Add more. Then Add Product Page open
 
4. fill the data and add product successfully added
 
5. new product added 
6. now update product previous value show here
 
7.New  value put
 
8 new value updated sucessfully 
9.showing here new updated  value 
10. Delete button 
11 Deleted successfully

 

<PackageReference Include="Dapper" Version="2.1.35" />
<PackageReference Include="Microsoft.Data.SqlClient" Version="5.2.0" />
<PackageReference Include="Microsoft.Extensions.Configuration.Abstractions" Version="8.0.0" />

Here I am using all these package and make sure about your connection string

## check also here one text file##

